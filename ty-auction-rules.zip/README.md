# TYP AUCTION TOURNAMENT RULES
This repository contains the expandable rules page for the TYP Auction Tournament, ready to deploy via GitHub Pages.